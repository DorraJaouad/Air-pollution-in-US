corr <- function( directory, threshold = 0){
  data <- vector()
  for (i in 1:332 ){
    h <- paste("/home/rstudio/",directory,"/",sprintf("%03d", i),".csv",sep='')
    file <-read.csv(h)
    if (complete("specdata", i)[[1,2]]> threshold){
      sub <- file[,c(2,3)][complete.cases(file),]
      data[length(data)+1]<- cor(sub$sulfate,sub$nitrate)
      }
  }
  data
}
