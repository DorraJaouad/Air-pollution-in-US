pollutantmean <- function (directory='specdata', pollutant, id=1:332 ){
  list_sum <- rep(0, length(id))
  list_num <- rep(0, length(id))
  for (i in 1:length(id) ){
    h <- paste("/home/rstudio/",directory,"/",sprintf("%03d", id[i]),".csv",sep='')
    file <- read.csv(h)
    file <- as.data.frame(file)
    col_pollutant <- file[pollutant][!is.na(file[pollutant])]
    list_sum[i] <- sum(col_pollutant)
    list_num[i] <- length(col_pollutant)
    if (is.na(list_sum[i])) {
      list_sum[i] <- 0
    }
  }
  n <- sum(list_sum)/sum(list_num)
  if (sum(list_num) ==0) {
    n <- 0
  }
  n
}