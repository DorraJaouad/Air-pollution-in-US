complete <- function(directory, id = 1:332 ){
  nobs <- rep(0,length(id))
  for (i in 1:length(id) ){
    h <- paste("/home/rstudio/",directory,"/",sprintf("%03d", id[i]),".csv",sep='')
    file <-read.csv(h)
    nobs[i] <- sum(complete.cases(file))
  }
  data <- data.frame(cbind(id,nobs))
  data
}